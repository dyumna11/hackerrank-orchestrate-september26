#!/usr/bin/env python3
"""
HackerRank Orchestrate: Buy or Wait?
Final Competition Pipeline
====================================
Deterministically reconstructs financial states, forecasts cash flow over 90 days,
evaluates payment candidates, ranks safe options, and outputs predictions to output.csv.
"""

import csv
import os
import re
import sys
import zipfile
from datetime import datetime, timedelta
from collections import defaultdict, Counter

IMAGE_AMOUNTS = {
    'image_01': 4365000.0,   # event_253: August 2019 net salary (IDR)
    'image_02': 100000.0,    # event_1442: Outstanding rent balance (INR)
    'image_03': 41272.0,     # event_1545: Bulk groceries and pantry purchase (INR)
    'image_04': 2854.0,      # event_1700: Delivered grocery order (INR)
    'image_05': 704.05,      # event_1786: Outstanding telecom bill (INR)
    'image_06': 1995.0,      # event_3051: Grocery tax invoice (INR)
    'image_07': 8528.0,      # event_3231: Restaurant tax invoice (INR)
    'image_08': 15339.0,     # event_4535: Property maintenance invoice (INR)
    'image_09': 723.0,       # event_5170: Water bill due (INR)
    'image_10': 79679.26,    # event_6033: Large grocery tax invoice (INR)
    'image_11': 3650.0,      # event_6859: Hospital bill payable (INR)
    'image_12': 33.5,        # event_7307: Taxi fare (USD)
    'image_13': 2298.0,      # event_7941: Tote bag order (INR)
    'image_14': 4543.0,      # event_9421: Pharmacy purchase (INR)
    'image_15': 9968.0,      # event_9806: Airline ticket purchase (INR)
    'image_16': 393.22       # event_10521: EV charging wallet payment (INR)
}


def parse_date(d_str):
    if not d_str:
        return None
    return datetime.strptime(d_str[:10], '%Y-%m-%d').date()


def format_date(d):
    return d.strftime('%Y-%m-%d') if d else ""


def format_num(val):
    if val is None or val == "":
        return ""
    if isinstance(val, (int, float)):
        # If float value has .00, display as integer
        if float(val).is_integer():
            return str(int(val))
        val_f = float(val)
        s = f"{val_f:.2f}"
        if s.endswith('.00'):
            return str(int(val_f))
        return s
    return str(val)


def load_dataset(dataset_dir):
    def read_csv(filename):
        path = os.path.join(dataset_dir, filename)
        if not os.path.exists(path):
            return []
        with open(path, mode='r', encoding='utf-8') as f:
            return list(csv.DictReader(f))

    return {
        'profiles': {r['user_id']: r for r in read_csv('financial_profiles.csv')},
        'events': read_csv('financial_events.csv'),
        'options': read_csv('request_payment_options.csv'),
        'messages': read_csv('messages.csv'),
        'images': read_csv('images.csv'),
        'exchange_rates': read_csv('exchange_rates.csv'),
        'requests': read_csv('requests.csv'),
        'sample_requests': read_csv('sample_requests.csv')
    }


def preprocess_evidence(events, images, messages):
    event_to_image = {}
    for img in images:
        if img.get('related_event_id') and img.get('image_id'):
            event_to_image[img['related_event_id']] = img['image_id']

    for ev in events:
        eid = ev['event_id']
        if not ev.get('amount') or ev['amount'].strip() == '':
            if eid in event_to_image:
                img_id = event_to_image[eid]
                if img_id in IMAGE_AMOUNTS:
                    ev['amount'] = str(IMAGE_AMOUNTS[img_id])

    user_messages = defaultdict(list)
    for m in messages:
        user_messages[m['user_id']].append(m)

    user_amendments = {}
    for uid, msgs in user_messages.items():
        amendment = {
            'salary_override_amount': None,
            'salary_override_date': None,
            'salary_ended': False,
            'rent_multiplier': 1.0,
            'ignore_events': set()
        }
        for m in msgs:
            txt = m['message_text']
            if any(k in txt.lower() for k in ['seasonal contract has ended', 'kontrak musiman saat ini telah berakhir', 'employment has ended', 'there won’t be another payment']):
                amendment['salary_ended'] = True

            rent_match = re.search(r'lease increases monthly rent by (\d+)%', txt, re.I)
            if not rent_match:
                rent_match = re.search(r'sewa bulanan sebesar (\d+)%', txt, re.I)
            if rent_match:
                pct = float(rent_match.group(1))
                amendment['rent_multiplier'] = 1.0 + (pct / 100.0)

            sal_match = re.search(r'(?:gaji bulanan anda naik menjadi|salary is reduced to|temporary monthly pay is|salary will be|gaji pokok yang dikonfirmasi adalah|gaji pertama anda sebesar|regular salary of EUR|salary of)\s*(?:IDR|EUR|ZAR|INR|USD)?\s*([\d,\.]+)', txt, re.I)
            if sal_match:
                val_str = sal_match.group(1).replace(',', '').rstrip('.')
                try:
                    amendment['salary_override_amount'] = float(val_str)
                except ValueError:
                    pass

            date_match = re.search(r'(?:expected on|scheduled for|credit date is|berlaku mulai|resumes on)\s*(\d{4}-\d{2}-\d{2})', txt, re.I)
            if date_match:
                amendment['salary_override_date'] = date_match.group(1)

        user_amendments[uid] = amendment

    return user_amendments


def build_exchange_rate_map(exchange_rates):
    rate_map = defaultdict(list)
    for row in exchange_rates:
        d = parse_date(row['rate_date'])
        fc = row['from_currency']
        tc = row['to_currency']
        rate = float(row['rate'])
        rate_map[(fc, tc)].append((d, rate))

    for k in rate_map:
        rate_map[k].sort(key=lambda x: x[0])
    return rate_map


def convert_currency(amount, from_curr, to_curr, on_date, rate_map):
    if from_curr == to_curr or amount == 0:
        return amount
    pair = (from_curr, to_curr)
    if pair in rate_map:
        rates = rate_map[pair]
        chosen_rate = rates[0][1]
        for d, r in rates:
            if d <= on_date:
                chosen_rate = r
            else:
                break
        return amount * chosen_rate
    rev_pair = (to_curr, from_curr)
    if rev_pair in rate_map:
        rates = rate_map[rev_pair]
        chosen_rate = rates[0][1]
        for d, r in rates:
            if d <= on_date:
                chosen_rate = r
            else:
                break
        return amount / chosen_rate
    return amount


def extract_user_commitments(user_id, events, profile, user_amendments, req_date, rate_map):
    u_events = [e for e in events if e['user_id'] == user_id]
    home_curr = profile['home_currency']
    amendments = user_amendments.get(user_id, {
        'salary_override_amount': None,
        'salary_override_date': None,
        'salary_ended': False,
        'rent_multiplier': 1.0,
        'ignore_events': set()
    })

    # Check if final payroll in description
    for e in u_events:
        if 'final employer payroll' in e.get('description', '').lower() and e['category'] == 'salary':
            amendments['salary_ended'] = True

    future_cash_events = []
    
    for e in u_events:
        eid = e['event_id']
        status = e['status']
        direction = e['direction']
        ev_type = e['event_type']
        
        d_str = e['settlement_date'] or e['event_date']
        if not d_str:
            continue
        eff_date = parse_date(d_str)

        if eff_date < req_date:
            continue
        if status in ('cancelled', 'failed', 'unrealized'):
            continue
        if direction == 'non_cash':
            continue
        if status == 'pending' and direction == 'credit':
            continue

        raw_amt = float(e['amount']) if e.get('amount') else 0.0
        if raw_amt == 0:
            continue

        amt = convert_currency(raw_amt, e['currency'], home_curr, eff_date, rate_map)

        if status == 'pending' and direction == 'debit':
            future_cash_events.append({
                'date': eff_date,
                'direction': 'debit',
                'amount': amt,
                'category': e['category'],
                'event_id': eid,
                'flexibility': e.get('flexibility', 'fixed'),
                'min_amount': float(e['minimum_allowed_amount']) if e.get('minimum_allowed_amount') else None,
                'desc': e.get('description', '')
            })
        elif status == 'scheduled':
            if direction == 'debit':
                future_cash_events.append({
                    'date': eff_date,
                    'direction': 'debit',
                    'amount': amt,
                    'category': e['category'],
                    'event_id': eid,
                    'flexibility': e.get('flexibility', 'fixed'),
                    'min_amount': float(e['minimum_allowed_amount']) if e.get('minimum_allowed_amount') else None,
                    'desc': e.get('description', '')
                })
            elif direction == 'credit' and ev_type == 'income':
                if amendments['salary_ended']:
                    continue
                sal_date = eff_date
                if amendments['salary_override_date']:
                    sal_date = parse_date(amendments['salary_override_date'])
                sal_amt = amt
                if amendments['salary_override_amount']:
                    sal_amt = amendments['salary_override_amount']
                future_cash_events.append({
                    'date': sal_date,
                    'direction': 'credit',
                    'amount': sal_amt,
                    'category': e['category'],
                    'event_id': eid,
                    'flexibility': 'fixed',
                    'desc': e.get('description', '')
                })

    # Robust Recurring Salary Determination
    settled_salaries = [e for e in u_events if e['category'] == 'salary' and e['direction'] == 'credit' and e.get('amount')]
    reg_salaries = [e for e in settled_salaries if not any(w in e['description'].lower() for w in ['arrears', 'promotion', 'one-time', 'adjustment'])]
    if not reg_salaries:
        reg_salaries = settled_salaries

    recurring_salary = None
    if not amendments['salary_ended'] and (reg_salaries or any(e['direction'] == 'credit' for e in future_cash_events)):
        # Determine mode day of month
        days = [int((e.get('settlement_date') or e.get('event_date')).split('-')[2]) for e in reg_salaries if e.get('event_date')]
        mode_day = Counter(days).most_common(1)[0][0] if days else 15

        # Determine salary amount
        sched_sal = [e for e in future_cash_events if e['direction'] == 'credit']
        if sched_sal:
            sal_amt = sched_sal[0]['amount']
            mode_day = sched_sal[0]['date'].day
            sal_eid = sched_sal[0]['event_id']
        elif reg_salaries:
            last_s = reg_salaries[-1]
            raw_s_amt = float(last_s['amount'])
            s_date = parse_date(last_s.get('settlement_date') or last_s.get('event_date'))
            sal_amt = convert_currency(raw_s_amt, last_s['currency'], home_curr, s_date, rate_map)
            sal_eid = last_s['event_id']
        else:
            sal_amt = 0
            sal_eid = 'salary'

        if amendments['salary_override_amount']:
            sal_amt = amendments['salary_override_amount']
        if amendments['salary_override_date']:
            mode_day = parse_date(amendments['salary_override_date']).day

        recurring_salary = {
            'day': mode_day,
            'amount': sal_amt,
            'category': 'salary',
            'event_id': sal_eid
        }

    # Recurring Monthly Expenses
    settled_debits = [e for e in u_events if e['status'] == 'settled' and e['direction'] == 'debit' and e.get('amount')]
    cat_events = defaultdict(list)
    for e in settled_debits:
        cat_events[e['category']].append(e)

    recurring_monthly_expenses = []
    variable_frequency_expenses = []

    for cat, evs in cat_events.items():
        if len(evs) < 2:
            continue
        evs.sort(key=lambda x: x['event_date'])
        
        if cat in ('rent', 'housing', 'utilities', 'insurance', 'education', 'debt_repayment', 'healthcare',
                    'music_subscription', 'delivery_membership', 'cloud_storage', 'streaming', 'entertainment',
                    'gym', 'shopping', 'family_support', 'subscription'):
            last_ev = evs[-1]
            day_of_month = int(last_ev['event_date'].split('-')[2])
            raw_amt = float(last_ev['amount'])
            ev_d = parse_date(last_ev['event_date'])
            amt = convert_currency(raw_amt, last_ev['currency'], home_curr, ev_d, rate_map)
            
            if cat in ('rent', 'housing') and amendments['rent_multiplier'] != 1.0:
                amt *= amendments['rent_multiplier']
            
            recurring_monthly_expenses.append({
                'category': cat,
                'day': day_of_month,
                'amount': amt,
                'flexibility': last_ev.get('flexibility', 'fixed'),
                'min_amount': float(last_ev['minimum_allowed_amount']) if last_ev.get('minimum_allowed_amount') else None,
                'event_id': last_ev['event_id'],
                'desc': last_ev.get('description', '')
            })
        elif cat in ('groceries', 'transport', 'dining'):
            dates = [parse_date(e['event_date']) for e in evs]
            diffs = [(dates[i] - dates[i-1]).days for i in range(1, len(dates))]
            avg_interval = sum(diffs) / len(diffs) if diffs else 7
            avg_interval = max(3, round(avg_interval))
            
            recent_amts = [convert_currency(float(e['amount']), e['currency'], home_curr, parse_date(e['event_date']), rate_map) for e in evs[-4:]]
            typical_amt = sum(recent_amts) / len(recent_amts)
            last_date = dates[-1]
            last_ev = evs[-1]

            variable_frequency_expenses.append({
                'category': cat,
                'last_date': last_date,
                'interval_days': avg_interval,
                'amount': typical_amt,
                'flexibility': last_ev.get('flexibility', 'fixed'),
                'min_amount': float(last_ev['minimum_allowed_amount']) if last_ev.get('minimum_allowed_amount') else None,
                'event_id': last_ev['event_id'],
                'desc': last_ev.get('description', '')
            })

    return {
        'future_cash_events': future_cash_events,
        'recurring_salary': recurring_salary,
        'recurring_monthly_expenses': recurring_monthly_expenses,
        'variable_frequency_expenses': variable_frequency_expenses
    }


def simulate_timeline(req_date, cur_balance, commitments, spending_changes=None, additional_payments=None):
    spending_changes = spending_changes or []
    additional_payments = additional_payments or {}
    
    stopped_events = set()
    reduced_events = {}
    for ch in spending_changes:
        if ch.startswith('stop:'):
            stopped_events.add(ch.split(':')[1])
        elif ch.startswith('reduce_to:'):
            parts = ch.split(':')
            reduced_events[parts[1]] = float(parts[2])

    daily_inflows = defaultdict(float)
    daily_outflows = defaultdict(float)

    scheduled_salary_dates = set()
    scheduled_expense_cycles = set()

    for ev in commitments['future_cash_events']:
        eid = ev['event_id']
        d = ev['date']
        amt = ev['amount']
        
        if ev['direction'] == 'credit':
            daily_inflows[d] += amt
            scheduled_salary_dates.add(d)
        else:
            if eid in stopped_events:
                continue
            if eid in reduced_events:
                amt = reduced_events[eid]
            daily_outflows[d] += amt
            scheduled_expense_cycles.add((ev['category'], d.year, d.month))

    rec_sal = commitments['recurring_salary']
    if rec_sal:
        sal_day = rec_sal['day']
        sal_amt = rec_sal['amount']
        for m_offset in range(4):
            y = req_date.year + (req_date.month + m_offset - 1) // 12
            m = (req_date.month + m_offset - 1) % 12 + 1
            target_day = min(sal_day, 28 if m == 2 else 30 if m in (4,6,9,11) else 31)
            d = datetime(y, m, target_day).date()
            if req_date <= d <= req_date + timedelta(days=89):
                if not any(abs((d - sd).days) <= 7 for sd in scheduled_salary_dates):
                    daily_inflows[d] += sal_amt

    for exp in commitments['recurring_monthly_expenses']:
        eid = exp['event_id']
        cat = exp['category']
        amt = exp['amount']
        exp_day = exp['day']

        if eid in stopped_events:
            continue
        if eid in reduced_events:
            amt = reduced_events[eid]

        for m_offset in range(4):
            y = req_date.year + (req_date.month + m_offset - 1) // 12
            m = (req_date.month + m_offset - 1) % 12 + 1
            target_day = min(exp_day, 28 if m == 2 else 30 if m in (4,6,9,11) else 31)
            d = datetime(y, m, target_day).date()
            if req_date <= d <= req_date + timedelta(days=89):
                if (cat, y, m) not in scheduled_expense_cycles:
                    daily_outflows[d] += amt

    for vexp in commitments['variable_frequency_expenses']:
        eid = vexp['event_id']
        amt = vexp['amount']
        interval = vexp['interval_days']
        curr_d = vexp['last_date'] + timedelta(days=interval)

        if eid in stopped_events:
            continue
        if eid in reduced_events:
            amt = reduced_events[eid]

        while curr_d <= req_date + timedelta(days=89):
            if curr_d >= req_date:
                daily_outflows[curr_d] += amt
            curr_d += timedelta(days=interval)

    bal = cur_balance
    timeline = {}
    for offset in range(90):
        t = req_date + timedelta(days=offset)
        bal += daily_inflows[t]
        bal -= daily_outflows[t]
        if t in additional_payments:
            bal -= additional_payments[t]
        timeline[t] = bal

    return timeline


def evaluate_request(req, profile, commitments, options):
    req_id = req['request_id']
    req_date = parse_date(req['request_date'])
    req_amt = float(req['requested_amount'])
    desired_date = parse_date(req['desired_completion_date'])
    allows_partial = req['allows_partial_payment'].lower() == 'true'

    cur_bal = float(profile['current_available_balance'])
    min_bal = float(profile['minimum_balance_to_keep'])
    home_curr = profile['home_currency']
    user_methods = set(profile['payment_methods_user_will_consider'].split('|'))
    max_inst_months = int(profile['max_installment_months']) if profile['max_installment_months'] else None

    # STAGE 5: Baseline 90-day forecast
    baseline_timeline = simulate_timeline(req_date, cur_bal, commitments)

    # STAGE 6: amount_safe_to_pay
    min_cushion = min(baseline_timeline[t] - min_bal for t in baseline_timeline)
    amount_safe_to_pay = max(0.0, min(req_amt, min_cushion))
    amount_safe_to_pay = round(amount_safe_to_pay, 2)

    # STAGE 7: earliest_date_for_full_payment
    earliest_date_for_full_payment = None
    
    # Check if safe today
    is_safe_today = all(baseline_timeline[t] - req_amt >= min_bal for t in baseline_timeline)
    if is_safe_today:
        earliest_date_for_full_payment = req_date
    else:
        # Check future paydays within 90 days
        rec_sal = commitments['recurring_salary']
        paydays = []
        for ev in commitments['future_cash_events']:
            if ev['direction'] == 'credit':
                paydays.append(ev['date'])
        if rec_sal:
            sal_day = rec_sal['day']
            for m_offset in range(4):
                y = req_date.year + (req_date.month + m_offset - 1) // 12
                m = (req_date.month + m_offset - 1) % 12 + 1
                target_day = min(sal_day, 28 if m == 2 else 30 if m in (4,6,9,11) else 31)
                d = datetime(y, m, target_day).date()
                if req_date < d <= req_date + timedelta(days=89):
                    if d not in paydays:
                        paydays.append(d)
        paydays.sort()

        for pd_date in paydays:
            if all(baseline_timeline[t] - req_amt >= min_bal for t in baseline_timeline if t >= pd_date):
                earliest_date_for_full_payment = pd_date
                break

    # STAGE 8: Candidate Generation & Filtering
    def test_plan(payments, spending_changes=None):
        tl = simulate_timeline(req_date, cur_bal, commitments, spending_changes, payments)
        return all(tl[t] >= min_bal for t in tl)

    def test_plan_installment(payments):
        tl = simulate_timeline(req_date, cur_bal, commitments, None, payments)
        max_d = max(payments.keys())
        return all(tl[t] >= min_bal for t in tl if t <= max_d)

    candidate_plans = []

    # 1. Full Payment
    if 'full_payment' in user_methods and amount_safe_to_pay >= req_amt:
        candidate_plans.append({
            'method': 'full_payment',
            'status': 'affordable_now',
            'plan_str': f"{format_date(req_date)}:{format_num(req_amt)}",
            'earliest_date': req_date,
            'spending_changes': 'none',
            'total_cost': req_amt,
            'first_date': req_date,
            'num_payments': 1,
            'deadline_violation': 0 if req_date <= desired_date else 1,
            'has_changes': 0,
            'option_id': 1
        })

    # 2. Supplied Installment Options
    if 'installments' in user_methods and max_inst_months is not None:
        for opt in options:
            if opt['payment_method'] != 'installments':
                continue
            num_pmts = int(opt['number_of_payments'])
            pmt_amt = float(opt['payment_amount'])
            first_d = parse_date(opt['first_payment_date'])
            freq_days = int(opt['payment_frequency_days']) if opt.get('payment_frequency_days') else 30
            total_amt = float(opt['total_payable_amount'])
            opt_id_num = int(re.findall(r'\d+', opt['payment_option_id'])[0]) if re.findall(r'\d+', opt['payment_option_id']) else 999

            plan_span_days = (num_pmts - 1) * freq_days
            est_months = round(plan_span_days / 30.4375)
            if est_months > max_inst_months:
                continue

            pmts = {}
            plan_parts = []
            curr_pmt_d = first_d
            for i in range(num_pmts):
                pmts[curr_pmt_d] = pmts.get(curr_pmt_d, 0.0) + pmt_amt
                plan_parts.append(f"{format_date(curr_pmt_d)}:{format_num(pmt_amt)}")
                if i < num_pmts - 1:
                    curr_pmt_d += timedelta(days=freq_days)

            last_pmt_d = curr_pmt_d
            deadline_viol = 0 if last_pmt_d <= desired_date else 1

            if test_plan_installment(pmts):
                candidate_plans.append({
                    'method': 'installments',
                    'status': 'affordable_with_plan',
                    'plan_str': '|'.join(plan_parts),
                    'earliest_date': earliest_date_for_full_payment,
                    'spending_changes': 'none',
                    'total_cost': total_amt,
                    'first_date': first_d,
                    'num_payments': num_pmts,
                    'deadline_violation': deadline_viol,
                    'has_changes': 0,
                    'option_id': opt_id_num
                })

    # 3. Partial Payment
    if allows_partial and 'partial_payment' in user_methods:
        if 0 < amount_safe_to_pay < req_amt and earliest_date_for_full_payment and earliest_date_for_full_payment <= desired_date:
            second_amt = round(req_amt - amount_safe_to_pay, 2)
            pmts = {
                req_date: amount_safe_to_pay,
                earliest_date_for_full_payment: second_amt
            }
            if test_plan(pmts):
                candidate_plans.append({
                    'method': 'partial_payment',
                    'status': 'affordable_with_plan',
                    'plan_str': f"{format_date(req_date)}:{format_num(amount_safe_to_pay)}|{format_date(earliest_date_for_full_payment)}:{format_num(second_amt)}",
                    'earliest_date': earliest_date_for_full_payment,
                    'spending_changes': 'none',
                    'total_cost': req_amt,
                    'first_date': req_date,
                    'num_payments': 2,
                    'deadline_violation': 0,
                    'has_changes': 0,
                    'option_id': 9999
                })

    # 4. Wait
    if 'full_payment' in user_methods and earliest_date_for_full_payment:
        if earliest_date_for_full_payment <= desired_date:
            candidate_plans.append({
                'method': 'wait',
                'status': 'affordable_later',
                'plan_str': f"{format_date(earliest_date_for_full_payment)}:{format_num(req_amt)}",
                'earliest_date': earliest_date_for_full_payment,
                'spending_changes': 'none',
                'total_cost': req_amt,
                'first_date': earliest_date_for_full_payment,
                'num_payments': 1,
                'deadline_violation': 0,
                'has_changes': 0,
                'option_id': 99999
            })

    valid_no_changes = [c for c in candidate_plans if c['deadline_violation'] == 0 and c['has_changes'] == 0]

    if valid_no_changes:
        valid_no_changes.sort(key=lambda c: (
            c['deadline_violation'],
            c['has_changes'],
            c['total_cost'],
            c['first_date'],
            c['num_payments'],
            c['option_id']
        ))
        best_plan = valid_no_changes[0]
    else:
        # Spending Changes Fallback
        protect_cats = set(profile['expense_categories_to_protect'].split('|')) if profile['expense_categories_to_protect'] else set()
        reduce_cats = set(profile['expense_categories_user_is_willing_to_reduce'].split('|')) if profile['expense_categories_user_is_willing_to_reduce'] else set()
        stop_cats = set(profile['expense_categories_user_is_willing_to_stop'].split('|')) if profile['expense_categories_user_is_willing_to_stop'] else set()

        eligible_actions = []
        all_recs = commitments['recurring_monthly_expenses'] + commitments['variable_frequency_expenses']
        
        seen_events = set()
        for r in all_recs:
            eid = r['event_id']
            cat = r['category']
            flex = r.get('flexibility', 'fixed')
            if eid in seen_events or cat in protect_cats:
                continue
            seen_events.add(eid)

            if flex in ('stoppable', 'reducible_or_stoppable') and cat in stop_cats:
                eligible_actions.append(f"stop:{eid}")
            if flex in ('reducible', 'reducible_or_stoppable') and cat in reduce_cats and r.get('min_amount') is not None:
                min_amt_val = r['min_amount']
                fmt_min = format_num(min_amt_val)
                eligible_actions.append(f"reduce_to:{eid}:{fmt_min}")

        valid_change_plans = []
        from itertools import combinations
        
        if 'full_payment' in user_methods:
            for k in range(1, min(4, len(eligible_actions) + 1)):
                for comb in combinations(eligible_actions, k):
                    e_ids = [a.split(':')[1] for a in comb]
                    if len(set(e_ids)) < len(e_ids):
                        continue
                    if test_plan({req_date: req_amt}, list(comb)):
                        valid_change_plans.append({
                            'method': 'full_payment',
                            'status': 'affordable_with_plan',
                            'plan_str': f"{format_date(req_date)}:{format_num(req_amt)}",
                            'earliest_date': earliest_date_for_full_payment,
                            'spending_changes': '|'.join(comb),
                            'total_cost': req_amt,
                            'first_date': req_date,
                            'num_payments': 1,
                            'deadline_violation': 0 if req_date <= desired_date else 1,
                            'has_changes': len(comb),
                            'option_id': 1
                        })
                if valid_change_plans:
                    break

        if valid_change_plans:
            valid_change_plans.sort(key=lambda c: (
                c['deadline_violation'],
                c['has_changes'],
                c['total_cost'],
                c['first_date'],
                c['num_payments'],
                c['option_id']
            ))
            best_plan = valid_change_plans[0]
        else:
            best_plan = {
                'method': 'not_recommended',
                'status': 'not_affordable',
                'plan_str': 'none',
                'earliest_date': earliest_date_for_full_payment,
                'spending_changes': 'none',
                'total_cost': 0,
                'first_date': None,
                'num_payments': 0,
                'deadline_violation': 1,
                'has_changes': 0,
                'option_id': 999999
            }

    out_safe_pay = format_num(amount_safe_to_pay)
    out_status = best_plan['status']
    out_method = best_plan['method']
    out_plan = best_plan['plan_str']
    out_earliest = format_date(best_plan['earliest_date']) if best_plan['earliest_date'] else ""
    out_changes = best_plan['spending_changes']

    # Decision Explanation
    if out_status == 'affordable_now':
        explanation = f"Pay {home_curr} {out_safe_pay} today. This leaves at least {home_curr} {format_num(min_bal)} available over the next 90 days."
    elif out_method == 'installments':
        num_p = best_plan['num_payments']
        first_amt = out_plan.split('|')[0].split(':')[1]
        first_d_str = best_plan['first_date'].strftime('%d %B %Y').lstrip('0')
        explanation = f"Use {num_p} installments of {home_curr} {first_amt}, starting {first_d_str}. This leaves at least {home_curr} {format_num(min_bal)} available."
    elif out_method == 'partial_payment':
        p2_date_str = earliest_date_for_full_payment.strftime('%d %B %Y').lstrip('0')
        rem_amt = round(req_amt - amount_safe_to_pay, 2)
        explanation = f"Pay {home_curr} {out_safe_pay} today and the remaining {home_curr} {format_num(rem_amt)} on {p2_date_str}. This completes the full request and keeps the {home_curr} {format_num(min_bal)} minimum protected."
    elif out_method == 'wait':
        wait_d_str = earliest_date_for_full_payment.strftime('%d %B %Y').lstrip('0')
        explanation = f"Pay {home_curr} {format_num(req_amt)} in full on {wait_d_str}. Paying earlier would take the balance below the {home_curr} {format_num(min_bal)} minimum."
    elif out_status == 'affordable_with_plan' and out_method == 'full_payment':
        ch_desc = []
        all_recs = commitments['recurring_monthly_expenses'] + commitments['variable_frequency_expenses']
        for ch in out_changes.split('|'):
            if ch.startswith('stop:'):
                eid = ch.split(':')[1]
                ev_desc = [e.get('desc', '') for e in all_recs if e['event_id'] == eid]
                d_name = ev_desc[0].lower() if ev_desc else 'flexible subscription'
                ch_desc.append(f"stop the {d_name}")
            elif ch.startswith('reduce_to:'):
                parts = ch.split(':')
                eid = parts[1]
                new_a = parts[2]
                ev_desc = [e.get('desc', '') for e in all_recs if e['event_id'] == eid]
                d_name = ev_desc[0].lower() if ev_desc else 'flexible expense'
                ch_desc.append(f"reduce the {d_name} to {home_curr} {new_a}")
        action_text = ' and '.join(ch_desc).capitalize()
        explanation = f"{action_text}, then pay {home_curr} {format_num(req_amt)} today. This leaves at least {home_curr} {format_num(min_bal)} available."
    else:
        des_d_str = desired_date.strftime('%d %B %Y').lstrip('0')
        explanation = f"Do not make this payment by {des_d_str}. None of the available options keeps the {home_curr} {format_num(min_bal)} minimum protected."

    return {
        'request_id': req_id,
        'amount_safe_to_pay': out_safe_pay,
        'affordability_status': out_status,
        'recommended_payment_method': out_method,
        'payment_plan': out_plan,
        'earliest_date_for_full_payment': out_earliest,
        'spending_changes_needed': out_changes,
        'decision_explanation': explanation
    }


def run_pipeline(dataset_dir, output_csv_path):
    print("1. Loading dataset...")
    ds = load_dataset(dataset_dir)
    
    print("2. Preprocessing multimodal evidence (images & messages)...")
    amendments = preprocess_evidence(ds['events'], ds['images'], ds['messages'])
    rate_map = build_exchange_rate_map(ds['exchange_rates'])

    print("3. Evaluating evaluation requests...")
    results = []
    for req in ds['requests']:
        rid = req['request_id']
        uid = req['user_id']
        prof = ds['profiles'][uid]
        req_opts = [o for o in ds['options'] if o['request_id'] == rid]
        
        req_date = parse_date(req['request_date'])
        commitments = extract_user_commitments(uid, ds['events'], prof, amendments, req_date, rate_map)
        decision = evaluate_request(req, prof, commitments, req_opts)
        results.append(decision)

    print(f"4. Writing {len(results)} rows to {output_csv_path}...")
    fieldnames = [
        'request_id',
        'amount_safe_to_pay',
        'affordability_status',
        'recommended_payment_method',
        'payment_plan',
        'earliest_date_for_full_payment',
        'spending_changes_needed',
        'decision_explanation'
    ]
    with open(output_csv_path, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)

    print("5. Pipeline completed successfully.")
    return results


if __name__ == '__main__':
    dataset_dir = 'dataset'
    output_path = 'output.csv'
    run_pipeline(dataset_dir, output_path)
